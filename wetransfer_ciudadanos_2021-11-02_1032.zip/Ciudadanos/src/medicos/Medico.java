package medicos;

import ciudadanos.Ciudadanos;

public class Medico extends Ciudadanos {
	
}
